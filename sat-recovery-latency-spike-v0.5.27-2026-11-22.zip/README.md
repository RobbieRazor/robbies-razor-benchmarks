# v0.5.27 SAT recovery under a simulated archive delivery delay

November 22, 2026. Internal experiment using the original frozen 24-case panel and its existing baseline and independent reverse readers.

Both readers recovered all three reference outputs byte for byte on every measured request. All 96 delayed requests completed correctly, as did the 480 requests that followed a delay in the same sequence. Each reader accounted for 960 measured requests, including 48 delayed requests. All 96 warmups were exact. The logs record 96 observed waits of at least 50 ms. On the delayed request, the median paired increase in elapsed time versus the same request position in the control sequence was 50.43 ms across readers, cases and passes.

These observations apply to a sequential local harness with a scheduled pause immediately before a local archive read. The outputs were the original CNF, transformation trace and reduced CNF. The experiment measured eventual completion and exact output. It did not exercise a live MCP or x402 service, client timeouts, retries, network congestion, or the 41 MiB limit from the earlier experiment. An independent external rerun remains pending.

## Audit this record

Read PROTOCOL.md for the design fixed before the run. The results directory holds the frozen case roster and runtime details in environment.json, each observation in requests.jsonl and the computed counts and paired timing in summary.json.

From the extracted evidence directory, run the following command with Python 3. It checks the harness digests, verifies the complete balanced schedule and recalculates the summary from the retained observations.

```sh
python3 verify.py results
```

## Re-execute with the original inputs

The source ZIP is a separate retained artifact. Its required SHA-256 is recorded in PROTOCOL.md. It supplies the original readers, archives and reference outputs. From the extracted evidence directory, run the following commands with the path to that ZIP and a fresh output directory.

```sh
python3 -B run.py /path/to/robbies-razor-sat-unseen-panel-v0.5.27.zip fresh-run
python3 verify.py fresh-run
```
