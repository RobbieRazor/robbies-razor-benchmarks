"""Check the complete schedule and recompute outcomes from the raw request records."""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
from statistics import median


def verify(out):
    here = Path(__file__).resolve().parent
    for line in (here / "protocol.sha256").read_text().splitlines():
        digest, name = line.split()
        if hashlib.sha256((here / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"Changed protocol file: {name}")
    env = json.loads((out / "environment.json").read_text())
    if env["frozen_zip_sha256"] not in (here / "PROTOCOL.md").read_text():
        raise ValueError("Source fingerprint differs from the protocol")
    cases = env["cases"]
    if len(cases) != 24 or len(set(cases)) != 24:
        raise ValueError("Unexpected case roster")
    rows = [json.loads(line) for line in (out / "requests.jsonl").read_text().splitlines()]
    cells = {}
    for row in rows:
        key = (row["case"], row["pass"], row["reader"], row["condition"], row["position"])
        if key in cells:
            raise ValueError(f"Duplicate request: {key}")
        cells[key] = row
    expected = []
    for p in (1, 2):
        for c in (cases if p == 1 else cases[::-1]):
            i = cases.index(c)
            readers = ("baseline", "reverse") if (i+p)%2 else ("reverse", "baseline")
            for arm in readers:
                modes = ("control", "spike") if (i+p+(arm=="reverse"))%2 else ("spike", "control")
                expected.append((c, p, arm, "warmup", 1))
                for mode in modes:
                    expected.extend((c, p, arm, mode, j) for j in range(1, 11))
    if list(cells) != expected:
        raise ValueError("Missing, extra or out-of-order request")
    for (_, _, _, mode, pos), row in cells.items():
        wanted = 50 if (mode, pos) == ("spike", 5) else 0
        if row["requested_wait_ms"] != wanted or row["elapsed_ns"] < row["observed_wait_ns"]:
            raise ValueError("Invalid timing or delay assignment")
        if not wanted and row["observed_wait_ns"] != 0:
            raise ValueError("Unexpected injected delay")
    warmups = [r for r in rows if r["condition"] == "warmup"]
    measured = [r for r in rows if r["condition"] != "warmup"]
    spikes = [r for r in measured if r["requested_wait_ms"]]
    follow = [r for r in measured if r["condition"] == "spike" and r["position"] > 5]
    differences_ms = [(r["elapsed_ns"]-cells[r["case"],r["pass"],r["reader"],"control",5]["elapsed_ns"])/1e6 for r in spikes]
    counts = lambda group: dict(Counter(r["status"] for r in group))
    exactness = all(r["status"] == "exact" for r in rows)
    delays_observed = sum(r["observed_wait_ns"] >= 50_000_000 for r in spikes)
    return {"warmups": counts(warmups), "all_measured": counts(measured),
            "delayed_fifth_reads": counts(spikes), "reads_after_spikes": counts(follow),
            "per_reader_measured": {a: counts([r for r in measured if r["reader"] == a])
                                    for a in ("baseline", "reverse")},
            "delays_at_least_50ms": delays_observed,
            "median_paired_fifth_read_change_ms": median(differences_ms),
            "exactness_criterion_met": exactness, "delay_criterion_met": delays_observed == 96}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results_directory", type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.results_directory), indent=2))
