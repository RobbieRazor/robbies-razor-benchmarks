"""Run the paired simulated-delivery experiment once; retain every request."""
import argparse
import hashlib
import json
import platform
import sys
import tempfile
import time
import zipfile
from pathlib import Path

FROZEN = "c8916e81e706cbfe943a157537b2f1a2756d5a19e7dadc6c3dafd4efc1e02106"
REFERENCES = ("original.cnf", "transformation-trace.json", "reduced.cnf")


def request(path, recover, expected, wait_ms):
    result = {"requested_wait_ms": wait_ms, "observed_wait_ns": 0}
    start = time.perf_counter_ns()
    try:
        if wait_ms:
            time.sleep(wait_ms / 1000)
            result["observed_wait_ns"] = time.perf_counter_ns() - start
        archive = path.read_bytes()
        recovered = recover(archive)["outputs"]
        result["elapsed_ns"] = time.perf_counter_ns() - start
        result["status"] = "exact" if recovered == expected else "output_mismatch"
    except Exception as exc:
        result.update(status="error", error=f"{type(exc).__name__}: {exc}",
                      elapsed_ns=time.perf_counter_ns() - start)
    return result


def execute(root, cases, log):
    sys.path.insert(0, str(root))
    from reader_paths import recover_binary, recover_independent
    readers = {"baseline": ("B_binary.zip", recover_binary),
               "reverse": ("R_reverse.zip", recover_independent)}
    for pass_no in (1, 2):
        case_order = cases if pass_no == 1 else list(reversed(cases))
        for case in case_order:
            index = cases.index(case)
            folder = root / "sources" / "cases" / case
            expected = tuple((folder / name).read_bytes() for name in REFERENCES)
            arms = ["baseline", "reverse"]
            if (index + pass_no) % 2 == 0:
                arms.reverse()
            for arm in arms:
                name, recover = readers[arm]
                common = {"case": case, "pass": pass_no, "reader": arm}
                modes = ["control", "spike"]
                if (index + pass_no + int(arm == "reverse")) % 2 == 0:
                    modes.reverse()
                for mode in ["warmup", *modes]:
                    count = 1 if mode == "warmup" else 10
                    for position in range(1, count + 1):
                        delay = 50 if mode == "spike" and position == 5 else 0
                        row = dict(common, condition=mode, position=position)
                        row.update(request(folder / name, recover, expected, delay))
                        log.write(json.dumps(row) + "\n")
                log.flush()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("frozen_zip", type=Path)
    parser.add_argument("new_output_directory", type=Path)
    args = parser.parse_args()
    if hashlib.sha256(args.frozen_zip.read_bytes()).hexdigest() != FROZEN:
        raise ValueError("Frozen ZIP fingerprint differs from the protocol")
    out = args.new_output_directory
    out.mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(args.frozen_zip) as archive, tempfile.TemporaryDirectory() as tmp:
        archive.extractall(tmp)
        root = next(Path(tmp).iterdir())
        original = json.loads((root / "evidence/frozen/protocol.json").read_text())
        cases = [entry["case_id"] for entry in original["cases"]]
        if len(cases) != 24 or len(set(cases)) != 24:
            raise ValueError("Unexpected frozen case set")
        environment = {"python": sys.version, "platform": platform.platform(),
                       "clock": str(time.get_clock_info("perf_counter")),
                       "frozen_zip_sha256": FROZEN, "cases": cases}
        (out / "environment.json").write_text(json.dumps(environment, indent=2) + "\n")
        with (out / "requests.jsonl").open("x") as log:
            execute(root, cases, log)


if __name__ == "__main__":
    main()
