# Simulated archive delivery delay on the frozen v0.5.27 panel

## Design fixed before execution

Question: Does either reader produce an incorrect result on or after one simulated 50 ms archive delivery delay? Use the 24 cases and the baseline and independent reverse readers from the original retained ZIP. Run two passes in one sequential Python process. Reverse case order on the second pass. Alternate reader order by original case index and pass, and condition order by case index, pass and reader. Each case, reader and pass has one checked warmup and two sequences of ten measured requests. The control sequence uses ordinary local file reads. The spike sequence waits 50 ms before reading the archive on request five only. The same case, archive and reader are used for the matched sequences. No retries or exclusions. No imposed memory limit, network connection, concurrency, service timeout, or client deadline.

Each request reads its archive from the local filesystem and passes the bytes to the frozen reader. OS caching is permitted. Elapsed time runs from the start of the delivery step to the return of the decoded outputs. Compare the original CNF, transformation trace JSON, and reduced CNF byte for byte against the frozen references after stopping the timer. Process setup, reference loading, output checks and logging are outside that timer.

Record every request and warmup. The exactness criterion requires all 96 warmups and all 1,920 measured requests to return three matching outputs. Separately require all 96 scheduled waits to last at least 50 ms as observed by the monotonic clock. Report outcomes at the delayed position and on the five subsequent requests. Report the median paired change in end-to-end elapsed time (spike minus control, both at position five), pooled across both readers and passes. Timing is descriptive. There is no speed threshold. This is a local internal delay simulation and tests neither production transport nor network reliability.

Original retained package SHA-256: c8916e81e706cbfe943a157537b2f1a2756d5a19e7dadc6c3dafd4efc1e02106
