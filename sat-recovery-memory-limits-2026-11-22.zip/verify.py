"""Independently check schedule coverage and render a per-case results table."""
import csv
import hashlib
import json
from collections import Counter
from itertools import product
from pathlib import Path
from statistics import median

base = Path(__file__).resolve().parent
evidence = base/'results'
for line in (base/'protocol.sha256').read_text().splitlines():
    digest, filename = line.split()
    assert hashlib.sha256((base/filename).read_bytes()).hexdigest() == digest
rows = [json.loads(line) for line in (evidence/'workers.jsonl').read_text().splitlines()]
summary = json.loads((evidence/'summary.json').read_text())
case_ids = sorted({r['case'] for r in rows})
assert len(case_ids) == 24
idx = {(r['case'],r['cap_MiB'],r['pass'],r['arm']):r for r in rows}
assert set(idx)==set(product(case_ids,(48,42,41),(1,2),('B','I')))
assert len(rows)==len(idx)==summary['recorded_workers']==288
for row in rows:
    if row['status']=='pass':
        assert row['exit_code']==0 and row['last_stage']=='report'
        assert row['exact_timed_recoveries']==60 and row['exact_warmups']==1
        assert len(row['batch_elapsed_ns'])==6 and min(row['batch_elapsed_ns'])>0
        assert row['final_KiB']['VmSize'] <= 1024*row['cap_MiB']
    elif row['status']=='timeout':
        assert row['worker_wall_ns']>0
    else:
        assert row['stderr'] and row['exit_code']!=0
for result in summary['results']:
    cap, arm = result['cap_MiB'],result['arm']
    group=[r for r in rows if r['cap_MiB']==cap and r['arm']==arm]
    statuses=Counter(r['status'] for r in group)
    counts=Counter(r['case'] for r in group if r['status']=='pass')
    assert result['workers']==dict(statuses) and result['cases_passing_both']==sum(k==2 for k in counts.values())
    print(cap,arm,statuses,'both',result['cases_passing_both'])
    if result['failures']:print('  ',Counter((r['last_stage'],r['stderr'].splitlines()[-1]) for r in group if r['status']!='pass'))
with (evidence/'case-matrix.csv').open('w',newline='') as f:
    writer=csv.writer(f)
    keys=list(product((48,42,41),('B','I'),(1,2)))
    writer.writerow(['case']+[f'{cap}MiB_{arm}_pass{p}' for cap,arm,p in keys])
    for case in case_ids:writer.writerow([case]+[idx[case,cap,p,arm]['status'] for cap,arm,p in keys])
