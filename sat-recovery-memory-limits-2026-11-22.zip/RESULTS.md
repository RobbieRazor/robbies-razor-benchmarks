# Constrained-memory results, November 22, 2026

All 288 scheduled processes are recorded. At 48 and 42 MiB both readers recovered all 24 cases in both passes. At 41 MiB both readers completed the same 20 cases in both passes. All 16 unsuccessful processes raised MemoryError during the first ten-recovery batch, after the single warmup passed. Zero output mismatches and zero timeouts were observed. This workload retains ten outputs before validation. The pilot cannot isolate which allocations caused the shared cutoff.

The four affected formulas were the two seeds (52701 and 52702) of each of overlap_one_level-g96 and overlap_recursive-g96. This set matches the four original cases for which the reverse archive was smaller and the reverse-to-baseline time ratio was at most 0.95 in both original passes. That comparison was made after the memory test.

The limit applies to Linux process virtual address space. It does not specify required physical RAM. The lowest tested limit with complete panel recovery was 42 MiB on this host and harness. This internal matrix gives no observed completion advantage to either reader at the three tested limits. It does not change the original warm timing result.
