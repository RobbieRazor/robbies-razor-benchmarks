# v0.5.27 constrained-memory panel

Internal stress test, November 22, 2026. This is a separate measurement on the frozen archive recovery paths. It uses the same SHA-256-identified inputs as the warm timing panel. The prior memory baseline informed the three selected ceilings.

## Protocol fixed before measurements

Use Linux RLIMIT_AS of 48, 42 and 41 MiB, in that order, for each reader process. Set both soft and hard ceilings after worker interpreter startup and before importing either reader. These are virtual-address-space limits, not resident-set quotas. Use Linux /proc/self/status for process peak and current memory. Include the same two reader imports, recovery paths, reference triples, warmup and batch dimensions as the earlier memory pilot. Give each case, pass and arm a fresh process. Each pass includes all 24 cases. Reverse the case order in pass two, and alternate which arm goes first across cases and passes. Run workers sequentially. Set the same 20 CPU-second and 30 wall-second limits.

The primary endpoint is the number of unique cases per arm and cap that finish both passes with every output exact. Also count all worker successes, discrepancies, allocation failures, other errors and timeouts. Each successful worker checks one warmup and six batches of ten recoveries. Preserve all outcomes, with no retries or removal. The worker emits stage markers before imports, preparation, warmup, each batch and validation, and final reporting, so setup and recovery failures can be distinguished. Per-batch elapsed times for completed workers and total process elapsed times are descriptive, not part of the original timing study. Disclose failures printing or recording evidence separately from recovery failures. Use measured successes at a cap as evidence conditional on the host and tested cases, not a universal minimum.

## Reproduce

Use Linux, Python 3, and the private original evidence ZIP. In a new output directory run `python3 /path/to/run.py /path/to/robbies-razor-sat-unseen-panel-v0.5.27.zip`. Keep worker.py beside run.py. The runner verifies the ZIP hash before extraction. The result set includes every planned worker and a summary by case, cap and arm. B denotes baseline recomputation. I denotes the independent reverse reader.
