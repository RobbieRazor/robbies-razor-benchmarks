"""Run one cell of the memory panel in a fresh Linux process."""
import gc
import json
import resource
import sys
import time
from pathlib import Path


def memory():
    wanted = {"VmRSS", "VmHWM", "VmSize", "VmPeak"}
    status = {}
    for line in Path("/proc/self/status").read_text().splitlines():
        key, _, value = line.partition(":")
        if key in wanted:
            n, unit = value.split()
            assert unit == "kB"
            status[key] = int(n)
    assert set(status) == wanted
    return status


def stage(label):
    print("STAGE", label, file=sys.stderr, flush=True)


def check(outputs, reference):
    if outputs != reference:
        raise ValueError("EXACT_OUTPUT_MISMATCH")


def main():
    directory, case, arm, cap = sys.argv[1:]
    root = Path(directory)
    stage("set_limits")
    resource.setrlimit(resource.RLIMIT_AS, (int(cap) * 2**20,) * 2)
    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
    stage("imports")
    sys.path.insert(0, str(root))
    from reader_paths import recover_binary, recover_independent
    stage("prepare")
    src = root / "sources" / "cases" / case
    fn, archive = {"B": (recover_binary, "B_binary.zip"),
                   "I": (recover_independent, "R_reverse.zip")}[arm]
    archive_bytes = (src / archive).read_bytes()
    reference = tuple((src / name).read_bytes() for name in
                      ("original.cnf", "transformation-trace.json", "reduced.cnf"))
    gc.collect()
    ready = memory()
    stage("warmup")
    check(fn(archive_bytes)["outputs"], reference)
    times = []
    for i in range(6):
        gc.collect()
        stage(f"recover_batch_{i+1}")
        start = time.perf_counter_ns()
        results = [fn(archive_bytes) for _ in range(10)]
        times.append(time.perf_counter_ns() - start)
        stage(f"validate_batch_{i+1}")
        for result in results:
            check(result["outputs"], reference)
        del result, results
    stage("report")
    end = memory()
    print(json.dumps({"ready_KiB": ready, "final_KiB": end, "batch_elapsed_ns": times,
                      "exact_timed_recoveries": 60, "exact_warmups": 1}))


if __name__ == "__main__":
    main()
