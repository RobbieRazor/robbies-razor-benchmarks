"""Record all attempted workers including unsuccessful ones."""
import hashlib
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
import zipfile
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXPECTED = "c8916e81e706cbfe943a157537b2f1a2756d5a19e7dadc6c3dafd4efc1e02106"
CAPS = [48, 42, 41]


def run_worker(root, case, arm, cap, env):
    cmd = [sys.executable, "-B", str(HERE/"worker.py"), str(root), case, arm, str(cap)]
    start = time.monotonic_ns()
    try:
        proc = subprocess.run(cmd, env=env, timeout=30, capture_output=True, text=True)
    except subprocess.TimeoutExpired as exc:
        return {"status": "timeout", "stderr": (exc.stderr or b"").decode(errors="replace"),
                "worker_wall_ns": time.monotonic_ns() - start}
    evidence = {"exit_code": proc.returncode, "stderr": proc.stderr,
                "worker_wall_ns": time.monotonic_ns() - start}
    if proc.returncode == 0:
        evidence.update(json.loads(proc.stdout))
        evidence["status"] = "pass"
    else:
        err = proc.stderr
        if "ValueError: EXACT_OUTPUT_MISMATCH" in err:
            status = "incorrect_output"
        elif "MemoryError" in err or "Cannot allocate memory" in err or "out of memory" in err.lower():
            status = "allocation_error"
        else:
            status = "worker_error"
        evidence["status"] = status
    return evidence


def main():
    bundle = Path(sys.argv[1])
    if hashlib.sha256(bundle.read_bytes()).hexdigest() != EXPECTED:
        raise ValueError("Unexpected frozen ZIP")
    rows = []
    env = dict(os.environ, PYTHONHASHSEED="0", PYTHONDONTWRITEBYTECODE="1",
               OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
    with tempfile.TemporaryDirectory() as tmp, Path("workers.jsonl").open("x") as out:
        with zipfile.ZipFile(bundle) as archive:
            archive.extractall(tmp)
        root = next(Path(tmp).iterdir())
        protocol = json.loads((root/"evidence/frozen/protocol.json").read_text())
        cases = [c["case_id"] for c in protocol["cases"]]
        assert len(cases) == len(set(cases)) == 24
        for cap in CAPS:
            for p in (1, 2):
                for case in (cases if p == 1 else cases[::-1]):
                    order = ["B","I"] if (cases.index(case) + p) % 2 else ["I","B"]
                    for arm in order:
                        row = {"case": case, "arm": arm, "pass": p, "cap_MiB": cap}
                        row.update(run_worker(root, case, arm, cap, env))
                        markers = [l[6:] for l in row["stderr"].splitlines() if l.startswith("STAGE ")]
                        row["last_stage"] = markers[-1] if markers else "unknown"
                        rows.append(row)
                        out.write(json.dumps(row)+"\n")
                        out.flush()
            print("Completed cap",cap,flush=True)
    details = []
    for cap in CAPS:
        for arm in ("B","I"):
            sub = [r for r in rows if r["cap_MiB"]==cap and r["arm"]==arm]
            assert len({(r["case"],r["pass"]) for r in sub})==len(sub)==48
            passed = Counter(r["case"] for r in sub if r["status"]=="pass")
            details.append({"cap_MiB":cap,"arm":arm, "workers":dict(Counter(r["status"] for r in sub)),
                "cases_passing_both":sum(passed[c]==2 for c in cases),
                "failures":[{k:r[k] for k in ("case","pass","status","last_stage")} for r in sub if r["status"]!="pass"]})
    summary={"python":platform.python_version(),"system":platform.platform(),
             "cpu":next(l.split(":",1)[1].strip() for l in Path("/proc/cpuinfo").read_text().splitlines() if l.startswith("model name")),
             "source_zip_sha256":EXPECTED,"planned_workers":288,"recorded_workers":len(rows),"results":details}
    Path("summary.json").write_text(json.dumps(summary,indent=2)+"\n")
if __name__=="__main__":
    main()
