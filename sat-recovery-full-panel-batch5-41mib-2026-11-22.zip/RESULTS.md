# Full panel at 41 MiB with five results per batch

November 22, 2026. Both baseline and reverse readers passed all 24 frozen cases in both passes. All 96 fresh processes completed, totaling 5,760 byte-checked measured recoveries and 96 checked warmups. No allocation errors, incorrect outputs or timeouts were recorded. The batch-retention worker matches the earlier four-case diagnostic byte for byte.

The earlier full-panel test at the same 41 MiB Linux virtual-address-space limit finished 20/24 cases per reader in both passes with batches of ten. In this execution with batches of five, both readers finished 24/24. Five results were validated and released before accumulating the next five; the total workload remained 60 recoveries per worker plus one warmup. Timing was diagnostic only. These first-party results apply to this frozen panel, harness and runtime. They support a batch-size choice for this workload; they establish neither a relative memory-efficiency advantage nor a general minimum RAM requirement.

See results/cases.csv for all 24 cases, results/workers.jsonl for every measured process and results/summary.json for the environment and per-reader counts.
