# Frozen v0.5.27 cases at batch size 5 and a 41 MiB virtual-address-space limit

## Scope and decision rule recorded before execution

Use the previous batch-retention worker verbatim. Cover the entire original frozen panel in original case order on pass 1 and reverse case order on pass 2. All 24 cases, both readers, two passes, 96 fresh sequential processes with no substitutions or retries. Success for an arm requires all three reference outputs to match for every recovery in all 48 workers for that arm; record all failures. Batch size five is selected from the earlier four-case internal diagnostic. Report exact completion, not a speed or physical-RAM claim. For context, compare with the previous full-panel size-ten run at 41 MiB; it is a historical comparison.

Each worker sets Linux RLIMIT_AS (both limits) to 41 MiB before importing the two readers. One checked warmup, then six ten-recovery rounds. The worker retains five results at a time, checks their original CNF, transformation trace and reduced CNF against the frozen bytes, and releases them. Garbage is explicitly collected once per ten-recovery round. Up to 20 CPU seconds and 30 seconds wall time per process. Seeds, 24 inputs, comparison archives and reference outputs are the retained v0.5.27 evidence; the runner checks the package SHA-256 before extracting.

## Reproduce

On Linux, run Python without optimization. From a fresh empty output directory run python3 /path/to/run.py /path/to/robbies-razor-sat-unseen-panel-v0.5.27.zip, then python3 /path/to/verify.py /path/to/output /path/to/robbies-razor-sat-unseen-panel-v0.5.27.zip. Keep worker.py alongside run.py. Verification checks the expected case set against the original ZIP, the harness digests, the complete schedule, status, warmups and recorded batches. Case-level outcomes are in results/cases.csv; complete logs are in results/workers.jsonl.
