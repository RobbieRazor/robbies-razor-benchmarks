"""Record all attempted workers including unsuccessful ones."""
import hashlib
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
import zipfile
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXPECTED = "c8916e81e706cbfe943a157537b2f1a2756d5a19e7dadc6c3dafd4efc1e02106"
def run_worker(root, case, arm, batch_size, env):
    cmd = [sys.executable, "-B", str(HERE/"worker.py"), str(root), case, arm, "41", str(batch_size)]
    start = time.monotonic_ns()
    try:
        proc = subprocess.run(cmd, env=env, timeout=30, capture_output=True, text=True)
    except subprocess.TimeoutExpired as exc:
        return {"status": "timeout", "stderr": (exc.stderr or b"").decode(errors="replace"),
                "worker_wall_ns": time.monotonic_ns() - start}
    evidence = {"exit_code": proc.returncode, "stderr": proc.stderr,
                "worker_wall_ns": time.monotonic_ns() - start}
    if proc.returncode == 0:
        evidence.update(json.loads(proc.stdout))
        evidence["status"] = "pass"
    else:
        err = proc.stderr
        if "ValueError: EXACT_OUTPUT_MISMATCH" in err:
            status = "incorrect_output"
        elif "MemoryError" in err or "Cannot allocate memory" in err or "out of memory" in err.lower():
            status = "allocation_error"
        else:
            status = "worker_error"
        evidence["status"] = status
    return evidence


def main():
    bundle = Path(sys.argv[1])
    if hashlib.sha256(bundle.read_bytes()).hexdigest() != EXPECTED:
        raise ValueError("Unexpected frozen ZIP")
    rows = []
    env = dict(os.environ, PYTHONHASHSEED="0", PYTHONDONTWRITEBYTECODE="1",
               OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
    with tempfile.TemporaryDirectory() as tmp, Path("workers.jsonl").open("x") as out:
        with zipfile.ZipFile(bundle) as archive:
            archive.extractall(tmp)
        root = next(Path(tmp).iterdir())
        protocol = json.loads((root/"evidence/frozen/protocol.json").read_text())
        cases = [c["case_id"] for c in protocol["cases"]]
        assert len(set(cases)) == len(cases) == 24
        for p in (1, 2):
            for case in (cases if p == 1 else cases[::-1]):
                order = ("B", "I") if (cases.index(case) + p) % 2 else ("I", "B")
                for arm in order:
                    row = {"case": case, "arm": arm, "pass": p, "cap_MiB": 41, "batch_size": 5}
                    row.update(run_worker(root, case, arm, 5, env))
                    markers = [l[6:] for l in row["stderr"].splitlines() if l.startswith("STAGE ")]
                    row["last_stage"] = markers[-1] if markers else "unknown"
                    row["warmup_completed"] = any(m.startswith("recover_round_") for m in markers)
                    rows.append(row)
                    out.write(json.dumps(row) + "\n")
                    out.flush()
            print(f"Completed pass {p} with {len(rows)} worker records",flush=True)
    summary = {
        "scope": "Internal 24-case exact-output completion test at RLIMIT_AS=41 MiB, batch size 5.",
        "python": platform.python_version(), "system": platform.platform(),
        "cpu": next(l.split(":",1)[1].strip() for l in Path("/proc/cpuinfo").read_text().splitlines() if l.startswith("model name")),
        "source_zip_sha256": EXPECTED, "cases": cases, "planned_workers": 96,
        "recorded_workers": len(rows), "arms": {}
    }
    for arm in ("B", "I"):
        group = [r for r in rows if r["arm"] == arm]
        passed = Counter(r["case"] for r in group if r["status"] == "pass")
        summary["arms"][arm] = {
            "statuses": dict(Counter(r["status"] for r in group)),
            "cases_passing_both": sum(passed[c] == 2 for c in cases),
            "exact_warmups_in_completed_workers": sum(r.get("exact_warmups",0) for r in group),
            "exact_recoveries_in_completed_workers": sum(r.get("exact_timed_recoveries",0) for r in group)
        }
    Path("summary.json").write_text(json.dumps(summary,indent=2) + "\n")
    print(json.dumps(summary["arms"]))
if __name__ == "__main__":
    main()
