"""Verify the full frozen case set and all attempted outcomes; write a case table."""
import csv
import hashlib
import json
import sys
import zipfile
from collections import Counter
from pathlib import Path

base = Path(__file__).resolve().parent
out, bundle = map(Path, sys.argv[1:])
for line in (base / "protocol.sha256").read_text().splitlines():
    digest, name = line.split()
    assert hashlib.sha256((base / name).read_bytes()).hexdigest() == digest
summary = json.loads((out / "summary.json").read_text())
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == summary["source_zip_sha256"]
with zipfile.ZipFile(bundle) as z:
    protocol = json.loads(z.read(bundle.stem + "/evidence/frozen/protocol.json"))
cases = [c["case_id"] for c in protocol["cases"]]
assert len(cases) == len(set(cases)) == 24 and cases == summary["cases"]
rows = [json.loads(s) for s in (out / "workers.jsonl").read_text().splitlines()]
expected = []
for p in (1, 2):
    for case in (cases if p == 1 else cases[::-1]):
        for arm in (("B","I") if (cases.index(case)+p)%2 else ("I","B")):
            expected.append((case,p,arm))
assert [(r["case"],r["pass"],r["arm"]) for r in rows] == expected
assert len(rows) == summary["recorded_workers"] == summary["planned_workers"] == 96
statuses = {}
for r in rows:
    assert r["cap_MiB"] == 41 and r["batch_size"] == 5
    statuses[r["case"],r["pass"],r["arm"]] = r["status"]
    if r["status"] != "pass":
        assert r["stderr"]
        continue
    stages = [s[6:] for s in r["stderr"].splitlines() if s.startswith("STAGE ")]
    required = ["set_limits","imports","prepare","warmup"]
    for k in range(1,7):
        for offset in (0,5):
            for action in ("recover","validate"):
                required.append(f"{action}_round_{k}_offset_{offset}")
    assert stages == required + ["report"] and r["exit_code"] == 0
    assert r["exact_warmups"] == 1 and r["exact_timed_recoveries"] == 60
    assert len(r["batch_elapsed_ns"]) == 12 and min(r["batch_elapsed_ns"]) > 0
for arm in ("B","I"):
    result = summary["arms"][arm]
    counts = Counter(r["status"] for r in rows if r["arm"] == arm)
    assert dict(counts)==result["statuses"]
    assert sum(all(statuses[c,p,arm]=="pass" for p in (1,2)) for c in cases)==result["cases_passing_both"]
    assert result["exact_recoveries_in_completed_workers"]==60*counts["pass"]
    assert result["exact_warmups_in_completed_workers"]==counts["pass"]
with (out / "cases.csv").open("w",newline="") as f:
    writer=csv.writer(f)
    writer.writerow(["case","baseline_pass_1","baseline_pass_2","reverse_pass_1","reverse_pass_2"])
    for c in cases:
        writer.writerow([c]+[statuses[c,p,arm] for arm in ("B","I") for p in (1,2)])
print(summary["arms"])
